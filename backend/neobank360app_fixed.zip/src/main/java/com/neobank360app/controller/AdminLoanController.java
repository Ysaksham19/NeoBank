//package com.neobank360app.controller;
//
//import com.neobank360app.dto.LoanDecisionDTO;
//import com.neobank360app.service.LoanDecisionService;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api/loans")
//public class AdminLoanController {
//
//    private final LoanDecisionService loanDecisionService;
//
//    public AdminLoanController(
//            LoanDecisionService loanDecisionService
//    ) {
//        this.loanDecisionService =
//                loanDecisionService;
//    }
//
//    @PutMapping("/{loanApplicationId}/decision")
//    @PreAuthorize("hasRole('ADMIN')")
//    public ResponseEntity<String> decideLoan(
//            @PathVariable Long loanApplicationId,
//            @RequestBody LoanDecisionDTO dto
//    ) {
//
//        return ResponseEntity.ok(
//                loanDecisionService.decideLoan(
//                        loanApplicationId,
//                        dto
//                )
//        );
//    }
//}

package com.neobank360app.controller;

import com.neobank360app.dto.LoanApplicationResponseDTO;
import com.neobank360app.dto.LoanDecisionDTO;
import com.neobank360app.service.LoanApplicationService;
import com.neobank360app.service.LoanDecisionService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loans")
public class AdminLoanController {

    private final LoanDecisionService loanDecisionService;

    private final LoanApplicationService loanApplicationService;

    public AdminLoanController(

            LoanDecisionService loanDecisionService,

            LoanApplicationService loanApplicationService
    ) {

        this.loanDecisionService = loanDecisionService;

        this.loanApplicationService = loanApplicationService;
    }

    // =========================================================
    // GET ALL APPLICATIONS (ADMIN)
    // =========================================================

    @GetMapping("/admin/applications")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<LoanApplicationResponseDTO>>
    getAllApplications() {

        return ResponseEntity.ok(

                loanApplicationService.getAllApplications()

        );
    }

    // =========================================================
    // APPROVE / REJECT LOAN
    // =========================================================

    @PutMapping("/{loanApplicationId}/decision")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> decideLoan(

            @PathVariable Long loanApplicationId,

            @RequestBody LoanDecisionDTO dto
    ) {

        return ResponseEntity.ok(

                loanDecisionService.decideLoan(
                        loanApplicationId,
                        dto
                )

        );
    }
}